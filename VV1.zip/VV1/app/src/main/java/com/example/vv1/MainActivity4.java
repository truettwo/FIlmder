package com.example.vv1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public class MainActivity4 extends AppCompatActivity {

    public interface TmdbService {
        @GET("movie/{id}")
        Call<Movie> getMovieDetails(@Path("id") int movieId, @Query("api_key") String apiKey);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        // Создайте экземпляр Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.themoviedb.org/3/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        // Создайте экземпляр службы
        TmdbService service = retrofit.create(TmdbService.class);

        // Определите movieId
        int movieId = 597; // Замените на реальный ID фильма

        // Сделайте вызов API
        Call<Movie> call = service.getMovieDetails(movieId, "6cca2127ce122aa9be379c2a829a6f6");

        call.enqueue(new Callback<Movie>() {
            @Override
            public void onResponse(Call<Movie> call, Response<Movie> response) {
                if (response.isSuccessful()) {
                    Movie movie = response.body();
                    // Здесь вы можете обновить ваш XML-макет данными из movie
                }
            }

            @Override
            public void onFailure(Call<Movie> call, Throwable t) {
                // Обработка ошибки
            }
        });
    }
}
